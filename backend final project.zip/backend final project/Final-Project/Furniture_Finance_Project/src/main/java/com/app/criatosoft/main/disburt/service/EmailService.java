package com.app.criatosoft.main.disburt.service;

import com.app.criatosoft.main.disburt.model.EmailSender;

public interface EmailService {

	public void sendEmail(EmailSender eml);
}
