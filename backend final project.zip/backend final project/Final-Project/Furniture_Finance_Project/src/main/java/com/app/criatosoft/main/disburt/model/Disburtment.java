package com.app.criatosoft.main.disburt.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Disburtment {
	@Id
	
	private long disburseId;
	
	private String disburseDate;
	private double proCharges;
	private double interest;
	private double disburseAmt;
	private long loanAmount;
	
	public long getDisburseId() {
		return disburseId;
	}
	public void setDisburseId(long disburseId) {
		this.disburseId = disburseId;
	}
	public String getDisburseDate() {
		return disburseDate;
	}
	public void setDisburseDate(String disburseDate) {
		this.disburseDate = disburseDate;
	}
	public double getProCharges() {
		return proCharges;
	}
	public void setProCharges(double proCharges) {
		this.proCharges = proCharges;
	}
	public double getInterest() {
		return interest;
	}
	public void setInterest(double interest) {
		this.interest = interest;
	}
	public double getDisburseAmt() {
		return disburseAmt;
	}
	public void setDisburseAmt(double disburseAmt) {
		this.disburseAmt = disburseAmt;
	}
	public long getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(long loanAmount) {
		this.loanAmount = loanAmount;
	}
	
	
	
}
