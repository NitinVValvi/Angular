package com.app.criatosoft.main.disburt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.criatosoft.main.disburt.model.Disburtment;

@Repository
public interface DisburseRepository extends JpaRepository<Disburtment, Integer> {

}
