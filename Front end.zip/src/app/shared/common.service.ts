import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Applicant } from 'app/model/applicant';
import { Disbursement } from 'app/model/disbursement';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  private serverUrl=environment.url;
  
disb:Disbursement;

  appl:Applicant[];


  constructor(private httpclient:HttpClient, private formbuilder:FormBuilder) { }
  
getSingleData(applicantId:string):Observable<Applicant>
{
  
  return this.httpclient.get<Applicant>(this.serverUrl+"/getId/"+applicantId);
  
}
getAll(){
  return this.httpclient.get<Applicant[]>(this.serverUrl+"/getAccepted")
}
  postData(tran:Disbursement):Observable<Disbursement>{
    return this.httpclient.post<Disbursement>(this.serverUrl+"/disburse",tran);
  }
  sendEmail(email:any){
    return this.httpclient.post<any>(this.serverUrl+"/send",email)
  }

  updateData(appl:Applicant):Observable<Applicant>
  {
    return this.httpclient.put<Applicant>(this.serverUrl+"/update",appl)
  }

  
  
}
