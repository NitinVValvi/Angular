import { MastermoduleModule } from './module/mastermodule/mastermodule.module';
import { Routes } from '@angular/router';

import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { LoginComponent } from './login/login.component';
import { EmployeeModule } from './module/employee/employee.module';
import { HomeComponent } from './home/home.component';
import { OperationexecutiveModule } from './module/operationexecutive/operationexecutive.module';
import { CreditmanagerModule } from './module/creditmanager/creditmanager.module';
import { RelationexecutiveModule } from './module/relationexecutive/relationexecutive.module';
import { ApplicationGenrationModule } from './module/application-genration/application-genration.module';
import { DocVerificationModule } from './module/doc-verification/doc-verification.module';
import { LoanSanctionModule } from './module/loan-sanction/loan-sanction.module';
import { DisbursementModule } from './module/disbursement/disbursement.module';


export const AppRoutes: Routes = [
  {
    path: '',
    component: HomeComponent
  }, 
  {
    path:"log",component:LoginComponent
  }
,
  {
    path: 'role',
    component: AdminLayoutComponent,
    children: [
      {path: 'admin', loadChildren: () => MastermoduleModule},
      {path: 'emp', loadChildren: () => EmployeeModule},
      {path:'operation',loadChildren:()=>OperationexecutiveModule},
      {path:'cr',loadChildren:()=>CreditmanagerModule},
      {path:'relation',loadChildren:()=>RelationexecutiveModule},
 
      {path:'appgen',loadChildren:()=>ApplicationGenrationModule},
      {path:'docgen',loadChildren:()=>DocVerificationModule},
      {path:'loang',loadChildren:()=>LoanSanctionModule},
      {path:'disg',loadChildren:()=>DisbursementModule}
    ]
  },
  {
    path: '**',
    redirectTo: 'dashboard'
  }
];



