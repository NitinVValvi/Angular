export class LoanSanction {
    loanSanctionId:number;
    loanAmount:number;
    sanctionDate:Date;
    sanctionLetter:any;
    remark:string;
    
}
