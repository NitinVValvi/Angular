export class Guarantor 
{
    guarantorId:number;
    guarantorName:string;
    guarantorMobileno:string;
    guarantorOccupation:string;
}
