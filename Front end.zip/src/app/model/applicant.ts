import { Address } from "./address";
import { BankDetails } from "./bank-details";
import { Disbursement } from "./disbursement";
import { Guarantor } from "./guarantor";
import { LoanSanction } from "./loan-sanction";
import { Nominee } from "./nominee";

export class Applicant
 {
     applicantId:string;
     applicantFname:string;
     applicantLname:string;
     applicantMobileno:string;
     applicantEmailid:string;
     applicantDob:string;
     applicantOccupation:string;
     applicantAadharno:string;
     applicantPanno:string;
     applicantLoanamt:number;
     status:string;
     cibilScore:number;
     address:Address;
     document:Document;
     bankdetails:BankDetails;
     nominee:Nominee;
     guarantor:Guarantor;
     loansanction:LoanSanction;
     disburse:Disbursement;



}
