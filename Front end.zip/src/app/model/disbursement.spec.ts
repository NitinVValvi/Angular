import { Disbursement } from './disbursement';

describe('Disbursement', () => {
  it('should create an instance', () => {
    expect(new Disbursement()).toBeTruthy();
  });
});
