

export class Disbursement 
{
    disburseId:any;
    disburseDate:string;
    proCharges:any;
    interest:any;
    disburseAmt:any;
    loanAmount:any;



}
