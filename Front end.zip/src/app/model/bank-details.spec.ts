import { BankDetails } from './bank-details';

describe('BankDetails', () => {
  it('should create an instance', () => {
    expect(new BankDetails()).toBeTruthy();
  });
});
