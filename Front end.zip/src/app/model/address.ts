export class Address 
{
    addrid:number;
    areaName:string;
    cityName:string;
    stateName:string;
    pinCode:number
}
