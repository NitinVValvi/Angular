import { Document } from './document';

describe('Document', () => {
  it('should create an instance', () => {
    expect(new Document()).toBeTruthy();
  });
});
