import { Guarantor } from './guarantor';

describe('Guarantor', () => {
  it('should create an instance', () => {
    expect(new Guarantor()).toBeTruthy();
  });
});
