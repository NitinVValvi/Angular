import { Nominee } from './nominee';

describe('Nominee', () => {
  it('should create an instance', () => {
    expect(new Nominee()).toBeTruthy();
  });
});
