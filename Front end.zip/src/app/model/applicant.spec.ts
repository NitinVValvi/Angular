import { Applicant } from './applicant';

describe('Applicant', () => {
  it('should create an instance', () => {
    expect(new Applicant()).toBeTruthy();
  });
});
