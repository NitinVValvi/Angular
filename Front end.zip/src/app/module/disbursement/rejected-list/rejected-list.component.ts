import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rejected-list',
  templateUrl: './rejected-list.component.html',
  styleUrls: ['./rejected-list.component.css']
})
export class RejectedListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  getback()
  {
    
  }

}
