import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplicantlistComponent } from './applicantlist/applicantlist.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { RejectedListComponent } from './rejected-list/rejected-list.component';
import { MakepaymentComponent } from './makepayment/makepayment.component';
import { DisburseLetterComponent } from './disburse-letter/disburse-letter.component';
import { StatusComponent } from './status/status.component';
import { HttpClientModule } from '@angular/common/http';


const discrouting: Routes = [
  {path: 'disg1', component: ApplicantlistComponent,
    children:[
      {
      path:'customer-details/:applicantId', component:CustomerDetailsComponent,
     children:[
      {
        path:'make-payment/:applicantId', component:MakepaymentComponent
                
      }
    ]
    }
    ]
  }
        
        // {
        //   path:'rejected-list', component:RejectedListComponent
        // }
   
      ]
  


//alert("IN DIS MODULE");
@NgModule({
  declarations: [ApplicantlistComponent, CustomerDetailsComponent, RejectedListComponent, MakepaymentComponent, DisburseLetterComponent, StatusComponent],
  imports: [
    CommonModule,RouterModule.forChild(discrouting),FormsModule,HttpClientModule,ReactiveFormsModule
  ]
})
export class DisbursementModule { }
