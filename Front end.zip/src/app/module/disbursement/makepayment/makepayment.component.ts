import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from 'app/shared/common.service';
import { Applicant } from 'app/model/applicant';
import { ActivatedRoute } from '@angular/router';
import { LoanSanction } from 'app/model/loan-sanction';
import { Disbursement } from 'app/model/disbursement';



@Component({
  selector: 'app-makepayment',
  templateUrl: './makepayment.component.html',
  styleUrls: ['./makepayment.component.css']
})
export class MakepaymentComponent implements OnInit {

  constructor(private location: Location, private formbuilder:FormBuilder,private commonservice:CommonService, private routes:ActivatedRoute) { }
  
  Disbusre:Disbursement

  applicantForm:FormGroup;

  applicant:Applicant;

  emailid:string;
 
  prosfee:number;
  
  finalamunt:number;
  email:any={
    tomail:String,
    subject:String,
    msg:String

  }
  ngOnInit(): void {
  //   this.routes.paramMap.subscribe(param1=>{
  //   this.commonservice.getSingleData((param1.get('applicantId'))).subscribe(data=>{
  //     this.applicant=data;
  //   })
  // })
   
  this.applicantForm=this.formbuilder.group({
    applicantId:[],
     applicantFname:[''],
     applicantLname:[''],
     applicantMobileno:[''],
     applicantEmailid:[''],
     applicantDob:[''],
     applicantOccupation:[''],
     applicantAadharno:[''],
     applicantPanno:[''],
     applicantLoanamt:[],
     status:[''],
     cibilScore:[],
      
     disburse:this.formbuilder.group({
      disburseId:[],
      disburseDate:[''],
      proCharges:[],
      interest:[],
      disburse:[],
      loanAmount:[]
     })

     
    })
    this.editData();
  }


    editData()
    {
      let appl:any=this.location.getState();

      this.applicantForm.get('applicantId').setValue(appl.applicantId);
      this.applicantForm.get('applicantFname').setValue(appl.applicantFname);
      this.applicantForm.get('applicantLname').setValue(appl.applicantLname);
      this.applicantForm.get('status').setValue(appl.status);
      this.applicantForm.get('applicantMobileno').setValue(appl.applicantMobileno);
      this.applicantForm.get('applicantEmailid').setValue(appl.applicantEmailid);
      this.applicantForm.get('applicantDob').setValue(appl.applicantDob);
      this.applicantForm.get('applicantOccupation').setValue(appl.applicantOccupation);
      this.applicantForm.get('applicantAadharno').setValue(appl.applicantAadharno);
      this.applicantForm.get('applicantPanno').setValue(appl.applicantPanno);
      this.applicantForm.get('applicantLoanamt').setValue(appl.applicantLoanamt);
      this.applicantForm.get('cibilScore').setValue(appl.cibilScore);
      
      
      this.applicantForm.get('disburseId').setValue(appl.disburse.disburseId);
      this.applicantForm.get('disburseDate').setValue(appl.disburse.disburseDate);
      this.applicantForm.get('proCharges').setValue(appl.disburse.proCharges);
      this.applicantForm.get('interest').setValue(appl.disburse.interest);
      this.applicantForm.get('disburseAmt').setValue(appl.disburse.disburseAmt);
      this.applicantForm.get('loanAmount').setValue(appl.disburse.loanAmount);
    
  }
  
  loanAmnt(loan:number):number{
   // alert("1st="+loan)
    this.finalamunt=loan-(loan*0.08);
    alert(this.finalamunt)
    return this.finalamunt;
    

  }

  profee(n:number):number{
    this.prosfee=n-(n-(n*0.08));
    return this.prosfee;
  }
  

  pay()
  {
    if(this.applicantForm.valid)
    {
      this.commonservice.postData(this.applicantForm.value).subscribe();
      this.location.back();
    //   this.email={
    //     toEmail:this.emailid,
    //     subject:"Welcome to Finance",
    //     textMsg:"Your MailId is "+this.Disbusre.value.Disbusre,
    //   }
    //   alert(this.email.toEmail);
    //   this.commonservice.sendEmail(this.email).subscribe();
    }
  }

  onSubmit()
  {
    this.commonservice.updateData(this.applicantForm.value).subscribe();
    this.location.back();
  }

  getback()
  {
     this.location.back();
  }

}


