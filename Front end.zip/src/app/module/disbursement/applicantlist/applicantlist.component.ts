import { Component, OnInit } from '@angular/core';
import { Applicant } from 'app/model/applicant';
import { Disbursement } from 'app/model/disbursement';
import { CommonService } from 'app/shared/common.service';

@Component({
  selector: 'app-applicantlist',
  templateUrl: './applicantlist.component.html',
  styleUrls: ['./applicantlist.component.css']
})
export class ApplicantlistComponent implements OnInit {

  applicant:Applicant[];

  constructor(private cs:CommonService) { }

  ngOnInit(): void {
    this.cs.getAll().subscribe(data=>{
      this.applicant=data;
    })
  }

}
