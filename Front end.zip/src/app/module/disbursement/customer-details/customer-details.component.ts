import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Applicant } from 'app/model/applicant';
import { CommonService } from 'app/shared/common.service';
import { ActivatedRoute } from '@angular/router';
import { param } from 'jquery';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {

applicant:Applicant;
  finalamunt: number;
  prosfee: number;

  constructor(private location:Location,private common:CommonService,private routes:ActivatedRoute) { }
  email:any={
    toEmail:String,
    subject:String,
    textMsg:String

  }
  ngOnInit(): void {
  this.getbyid();        
  }
  loanAmnt(loan:number):number{
    // alert("1st="+loan)
     this.finalamunt=loan-(loan*0.08);
    // alert(this.finalamunt)
     return this.finalamunt;
     
 
   }
 
   profee(n:number):number{
     this.prosfee=n-(n-(n*0.08));
     return this.prosfee;
   }

  getbyid()
  {
    this.routes.paramMap.subscribe(param1=>{
      this.common.getSingleData(param1.get('applicantId')).subscribe(data=>{
        this.applicant=data;
      })
    })
    
     
  }
  getback()
  {
     this.location.back();
  }
  makepayment(applicant){
    this.common.updateData(applicant).subscribe();
    this.email={
      toEmail:applicant.applicantEmailid,
      subject:"Loan Disbursement",
      textMsg:"Loan Amount of Rs:"+applicant.disburse.disburseAmt+" is credited in your Account No:"+applicant.bankdetails.bankAccountno,
    }
    alert(this.email.toEmail);
    this.common.sendEmail(this.email).subscribe();

  }

}
