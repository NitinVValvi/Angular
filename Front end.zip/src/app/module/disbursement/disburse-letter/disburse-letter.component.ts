import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disburse-letter',
  templateUrl: './disburse-letter.component.html',
  styleUrls: ['./disburse-letter.component.css']
})
export class DisburseLetterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
