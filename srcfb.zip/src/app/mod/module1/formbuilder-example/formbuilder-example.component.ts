import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-formbuilder-example',
  templateUrl: './formbuilder-example.component.html',
  styleUrls: ['./formbuilder-example.component.css'],
})
export class FormbuilderExampleComponent implements OnInit {
  constructor(private formbuilder: FormBuilder) {}

  loginForm: FormGroup;
  ngOnInit(): void {
    this.loginForm = this.formbuilder.group({
      username: ['', [Validators.required, Validators.minLength(4)]],
      password: ['', [Validators.required, Validators.minLength(8)]],
    });
  }
  fillform() {
    this.loginForm.patchValue({
      username: 'nitin',
      password: 'nitin@123',
    });
  }
  resetvalue() {
    alert('Reset');
    this.loginForm.reset();
  }

  onSubmit() {
    alert('Submit call');
    console.log('UserName = ' + this.loginForm.controls['username'].value);
    console.log('Password = ' + this.loginForm.controls['password'].value);
  }
}
