import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormbuilderExampleComponent } from './formbuilder-example/formbuilder-example.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ValidationsComponent } from './validations/validations.component';
import { ValidationsListComponent } from './validations-list/validations-list.component';

@NgModule({
  declarations: [
    FormbuilderExampleComponent,
    ValidationsComponent,
    ValidationsListComponent,
  ],
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  exports: [
    FormbuilderExampleComponent,
    ValidationsComponent,
    ValidationsListComponent,
  ],
})
export class Module1Module {}
