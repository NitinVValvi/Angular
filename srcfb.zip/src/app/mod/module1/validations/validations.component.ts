import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Student } from 'src/app/model/student';
import { CommonService } from 'src/app/shared/common.service';

@Component({
  selector: 'app-validations',
  templateUrl: './validations.component.html',
  styleUrls: ['./validations.component.css'],
})
export class ValidationsComponent implements OnInit {
  constructor(
    private formbuiler: FormBuilder,
    public commonService: CommonService
  ) {}

  registrationForm: FormGroup;

  ngOnInit(): void {
    this.registrationForm = this.formbuiler.group({
      fname: [
        '',
        [
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(12),
        ],
      ],
      lname: [
        '',
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(15),
        ],
      ],
      email: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(7)]],
      mobileno: ['', [Validators.required, Validators.maxLength(10)]],
      address: this.formbuiler.group({
        cityname: ['', [Validators.required]],
        areaname: ['', [Validators.required]],
      }),
    });
  }
  onSubmitCall(stu: Student) {
    alert('submit');
    console.log('FirstName = ' + this.registrationForm.controls['fname'].value);
    console.log('LastName = ' + this.registrationForm.controls['lname'].value);
    if (stu.id == 0) {
      this.commonService.postData(stu).subscribe();
      window.location.reload();
    } else {
      this.commonService.updatedata(stu).subscribe();
      window.location.reload();
    }
  }

  fillform() {
    this.registrationForm.patchValue({
      fname: 'nitin',
      lname: 'valvi',
      email: 'nvvalvi@gmail.com',
      password: 'nitin1234',
      mobileno: '9832978478',
      address: {
        areaname: 'navipeth',
        cityname: 'pune',
      },
    });
  }
  resetf() {
    alert('Reset');
    this.registrationForm.reset();
  }
}
