import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/model/student';
import { CommonService } from 'src/app/shared/common.service';

@Component({
  selector: 'app-validations-list',
  templateUrl: './validations-list.component.html',
  styleUrls: ['./validations-list.component.css'],
})
export class ValidationsListComponent implements OnInit {
  constructor(private commonService: CommonService) {}

  stuList: Student[];
  ngOnInit(): void {
    this.commonService.getData().subscribe((data: Student[]) => {
      this.stuList = data;
    });
  }

  deleteform(id: number) {
    this.commonService.deletedata(id).subscribe();
    window.location.reload();
  }

  editform(stu: Student) {
    this.commonService.s = Object.assign({}, stu);
  }
}
