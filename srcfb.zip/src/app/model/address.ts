export class Address {
  areaname: string;
  cityname: string;
}
