import { Address } from './address';

export class Student {
  id: number;
  fname: string;
  lname: string;
  email: string;
  password: string;
  mobileno: string;
  address: Address;
}
