import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from '../model/student';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  constructor(private http: HttpClient) {}

  url: string = 'http://localhost:3000/Student';
  s: Student = {
    id: 0,
    fname: '',
    lname: '',
    email: '',
    password: '',
    mobileno: '',
    address: {
      areaname: '',
      cityname: '',
    },
  };

  getData(): Observable<Student[]> {
    return this.http.get<Student[]>(this.url);
  }

  postData(stu: Student): Observable<Student> {
    return this.http.post<Student>(this.url, stu);
  }
  deletedata(id: number) {
    return this.http.delete(this.url + '/' + id);
  }

  updatedata(stu: Student): Observable<Student> {
    return this.http.put<Student>(this.url + '/' + stu.id, stu);
  }
}
