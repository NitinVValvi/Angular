import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'appFilter' })
export class FilterPipe implements PipeTransform {
  transform(data: any[], searchData: string): any[] {
    if (!data) {
      return [];
    }
    if (!searchData) {
      return data;
    }
    searchData = searchData.toLocaleLowerCase();

    return data.filter((it) => {
      return it.toLocaleLowerCase().includes(searchData);
    });
  }
}
