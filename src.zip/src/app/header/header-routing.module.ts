import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

export const headerroute: Routes = [
  {
    path: 'employee',
    loadChildren: () =>
      import('src/app/employee/employee.module').then(
        (module) => module.EmployeeModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forChild(headerroute)],
  exports: [RouterModule],
})
export class HeaderRoutingModule {}
