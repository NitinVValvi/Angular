import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Student } from 'src/app/model/student';

@Component({
  selector: 'app-button-one',
  templateUrl: './button-one.component.html',
  styleUrls: ['./button-one.component.css'],
})
export class ButtonOneComponent implements OnInit {
  @Input() name: string;

  @Input() student: Student;

  @Output() clickNowEvent = new EventEmitter();

  message: string = 'Hello I am child';
  constructor() {}

  ngOnInit(): void {}

  clickhere() {
    console.log('click here method');
    this.clickNowEvent.emit(this.message);
  }
}
