import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Employee } from 'src/app/model/employee';
import { CommonService } from 'src/app/shared/common.service';

@Component({
  selector: 'app-register-employee',
  templateUrl: './register-employee.component.html',
  styleUrls: ['./register-employee.component.css'],
})
export class RegisterEmployeeComponent implements OnInit {
  registerEmployee: FormGroup;
  constructor(
    public common: CommonService,
    private locations: Location,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.registerEmployee = this.fb.group({
      id: [],
      name: [''],
      mblist: [
        {
          id: [],
          mobno: [''],
        },
      ],
    });
  }
  onSubmit() {}
  addProduct(emp: Employee) {
    this.common.registerEmployee(emp).subscribe();
    console.log('register successfully');
    window.location.reload();
  }

  goBack() {
    this.locations.back();
  }
}
