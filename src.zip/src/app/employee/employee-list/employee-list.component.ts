import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee';
import { MobileNo } from 'src/app/model/mobile-no';
import { CommonService } from 'src/app/shared/common.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
})
export class EmployeeListComponent implements OnInit {
  constructor(private common: CommonService) {}

  empList: Employee[];

  ngOnInit(): void {
    this.common.getEmployees().subscribe((list) => (this.empList = list));
  }
  deleteEmp(id: number) {}
}
