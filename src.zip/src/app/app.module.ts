import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';

import { FilterPipe } from './filter.pipe';
import { HighlightDirective } from './highlight.directive'; // -> imported filter pipe

@NgModule({
  declarations: [AppComponent, FilterPipe, HighlightDirective],
  imports: [BrowserModule, FormsModule],
  bootstrap: [AppComponent],
})
export class AppModule {}
