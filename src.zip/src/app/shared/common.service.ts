import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  private serverurl = environment.url;
  constructor(private http: HttpClient, private router: Router) {}

  e: Employee = {
    id: 0,
    name: '',
    address: '',
    mblist: [
      {
        id: 0,
        mobno: '',
      },
    ],
  };

  getEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.serverurl + '/allemp');
  }

  registerEmployee(emp: Employee): Observable<Employee> {
    return this.http.post<Employee>(this.serverurl + '/addemp', emp);
  }
}
