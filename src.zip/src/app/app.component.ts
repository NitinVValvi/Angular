import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  // title = 'angular-text-search-highlight';
  searchText = '';
  characters = [
    'Nitin',
    'Mangesh',
    'Rahul',
    'Pranit',
    'Amit',
    'Jayesh',
    'Kalpesh',
    'Shreyas',
    'Rohan',
    'Sunil',
    'Mohan',
  ];
}
