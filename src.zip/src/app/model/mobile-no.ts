export class MobileNo {
  id: number;
  mobno: string;
}
