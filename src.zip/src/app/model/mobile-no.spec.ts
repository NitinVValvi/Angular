import { MobileNo } from './mobile-no';

describe('MobileNo', () => {
  it('should create an instance', () => {
    expect(new MobileNo()).toBeTruthy();
  });
});
