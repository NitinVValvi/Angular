import { MobileNo } from './mobile-no';

export class Employee {
  id: number;
  name: string;
  address: string;
  mblist: MobileNo[];
}
