export class Student {
  id: number;
  name: string;
  address: string;
}
