import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-reactive-form-example',
  templateUrl: './reactive-form-example.component.html',
  styleUrls: ['./reactive-form-example.component.css'],
})
export class ReactiveFormExampleComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}

  loginForm = new FormGroup({
    username: new FormControl(),
    password: new FormControl(),
  });

  submitButtonCall() {
    alert('Reactive form');
    console.log('UserName =' + this.loginForm.controls['username'].value);
    console.log('password =' + this.loginForm.controls['password'].value);
  }
}
