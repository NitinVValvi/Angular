import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-nested-reactive-form-example',
  templateUrl: './nested-reactive-form-example.component.html',
  styleUrls: ['./nested-reactive-form-example.component.css'],
})
export class NestedReactiveFormExampleComponent implements OnInit {
  [x: string]: any;
  constructor() {}

  ngOnInit(): void {}

  loginForm = new FormGroup({
    username: new FormControl(),
    password: new FormControl(),
    addressForm: new FormGroup({
      areaname: new FormControl(),
      cityname: new FormControl(),
    }),
  });

  submitButton() {
    alert('nested form submit');
    console.log('UserName = ' + this.loginForm.controls['username'].value);
    console.log('Password = ' + this.loginForm.controls['username'].value);
    console.log(
      'AreaName = ' + this.loginForm.controls['addressForm'].value.areaname
    );
    console.log(
      'CityName = ' + this.loginForm.controls['addressForm'].value.cityname
    );
  }
}
