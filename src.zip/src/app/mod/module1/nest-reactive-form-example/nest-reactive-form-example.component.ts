import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-nest-reactive-form-example',
  templateUrl: './nest-reactive-form-example.component.html',
  styleUrls: ['./nest-reactive-form-example.component.css'],
})
export class NestReactiveFormExampleComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}

  registrationForm = new FormGroup({
    firstname: new FormControl(),
    lastname: new FormControl(),
    email: new FormControl(),
    password: new FormControl(),
    mobno: new FormControl(),
    addressForm: new FormGroup({
      areaname: new FormControl(),
      cityname: new FormControl(),
    }),
  });

  onSubmit() {
    alert('submit form');
    console.log(
      'FirstName = ' + this.registrationForm.controls['firstname'].value
    );
    console.log(
      'LastName = ' + this.registrationForm.controls['lastname'].value
    );
    console.log('Email ID =' + this.registrationForm.controls['email'].value);
    console.log(
      'Password =' + this.registrationForm.controls['password'].value
    );

    console.log(
      'AreaName = ' +
        this.registrationForm.controls['addressForm'].value.areaname
    );
    console.log(
      'CityName = ' +
        this.registrationForm.controls['addressForm'].value.cityname
    );
  }
}
