import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-driven-example',
  templateUrl: './template-driven-example.component.html',
  styleUrls: ['./template-driven-example.component.css'],
})
export class TemplateDrivenExampleComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}

  loginForm = {
    userName: '',
    password: '',
  };
  submitButtonCall() {
    alert('In Submit');
    console.log('UserName =' + this.loginForm.userName);
    console.log('Password =' + this.loginForm.password);
  }
}
