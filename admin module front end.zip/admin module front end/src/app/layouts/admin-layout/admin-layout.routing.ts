import { DashboardComponent } from './../../module/mastermodule/dashboard/dashboard.component';
import { Routes } from '@angular/router';



export const AdminLayoutRoutes: Routes = [
    { path: 'dashboard',      component: DashboardComponent },

];
