import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { Employee } from "app/model/employee";
import { CommonService } from "app/module/shared/common.service";
import { data } from "jquery";
export interface user {
  username: string;
  password: string;
  repassword: string;
  email: string;
}
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  u: user = {
    username: "",
    password: "",
    repassword: "",
    email: "",
  };
  emp: Employee;
  constructor(private router: Router, public commonservice: CommonService) {}
  username: string = "";
  password: string = "";
  ngOnInit() {}

  // signup(u) {
  //   console.log("signup");
  // }
  login(u) {
    this.commonservice.checklogin(u.username, u.password).subscribe((data) => {
      this.emp = data;
    });
    if (this.emp != null) {
      if (this.emp.employeedesignation === "admin") {
        alert("wellCome chief " + this.emp.employeename);
        sessionStorage.setItem("role", "admin");
        this.router.navigateByUrl("role/admin/adminbash");
      }
      if (this.emp.employeedesignation === "appligen") {
        alert("wellCome chief " + this.emp.employeename);
        sessionStorage.setItem("role", "appgen");
        this.router.navigateByUrl("role/appgen/appgen1");
      }
      if (this.emp.employeedesignation === "docverify") {
        alert("wellCome chief " + this.emp.employeename);
        sessionStorage.setItem("role", "docgen");
        this.router.navigateByUrl("role/docgen/docgen1");
      }
      if (this.emp.employeedesignation === "loanSanction") {
        alert("wellCome chief " + this.emp.employeename);
        sessionStorage.setItem("role", "loang");
        this.router.navigateByUrl("role/loang/loang1");
      }
      if (this.emp.employeedesignation === "loanDisbus") {
        alert("wellCome chief " + this.emp.employeename);
        sessionStorage.setItem("role", "disg");
        this.router.navigateByUrl("role/disg/disg1");
      }
    }
  }
}
