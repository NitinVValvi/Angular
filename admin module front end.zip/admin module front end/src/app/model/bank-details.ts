export class BankDetails 
{
    bankId:number;
    bankName:string;
    bankBranchname:string;
    bankAccountno:string;
    bankIfsccode:string;
    bankAddress:string;
}
