export class Document 
{
    docId:number;
    aadharcard:[];
    panCard:[];
    cancelledCheque:[];
    passbook:[];
    signature:[];
    photo:[];
    quotation:[];

}
