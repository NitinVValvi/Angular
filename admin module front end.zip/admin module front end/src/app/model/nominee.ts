export class Nominee
 {
     nomid:number;
     nomName:string;
     nomRelation:string;
     nomDob:string;
     nomAge:number;
}
