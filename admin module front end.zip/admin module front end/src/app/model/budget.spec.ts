import { Budget } from './budget';

describe('Budget', () => {
  it('should create an instance', () => {
    expect(new Budget()).toBeTruthy();
  });
});
