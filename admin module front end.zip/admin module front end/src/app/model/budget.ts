export class Budget {
    budgetId:number;
	duration:string;
	budgetAmount:any;
	currentAmount:any;
}
