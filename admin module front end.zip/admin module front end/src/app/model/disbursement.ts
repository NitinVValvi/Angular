

export class Disbursement 
{
    id:number;
    loanAmt:any;
    proCharges:any;
    interest:any;
    Applicant:{
        applicantid:number;
    }

}
