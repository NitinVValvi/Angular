import { Address } from "./address";
import { BankDetails } from "./bank-details";
import { Guarantor } from "./guarantor";
import { Nominee } from "./nominee";

export class Applicant
 {
     applicantId:string;
     applicantFname:string;
     applicantLname:string;
     applicantMobileno:string;
     applicantEmailId:string;
     applicantDob:string;
     applicantOccupation:string;
     applicantAadharno:string;
     applicantPanno:string;
     applicantLoanamt:string;
     status:string;
     address:Address;
     document:Document;
     bankdetails:BankDetails;
     nominee:Nominee;
     guarantor:Guarantor;


}
