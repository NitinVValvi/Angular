export class Employee {
    employeeid:any;
    employeename:string;
    employeeemail:any;
    employeepassword:any;
    employeemobile:any;
    employeedesignation:any;
    employeesalary:any;
}
