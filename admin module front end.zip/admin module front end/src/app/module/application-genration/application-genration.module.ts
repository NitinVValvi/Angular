import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppcompComponent } from './appcomp/appcomp.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

const appgrouting: Routes = [
  {path: 'appgen1', component: AppcompComponent}
]

@NgModule({
  declarations: [AppcompComponent],
  imports: [
    CommonModule,RouterModule.forChild(appgrouting),FormsModule
  ]
})
export class ApplicationGenrationModule { }
