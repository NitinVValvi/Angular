import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appcomp',
  templateUrl: './appcomp.component.html',
  styleUrls: ['./appcomp.component.css']
})
export class AppcompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
