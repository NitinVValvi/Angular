import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disburcelist',
  templateUrl: './disburcelist.component.html',
  styleUrls: ['./disburcelist.component.css']
})
export class DisburcelistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
