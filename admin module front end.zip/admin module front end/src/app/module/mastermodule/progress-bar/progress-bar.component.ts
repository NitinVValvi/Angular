import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Applicant } from 'app/model/applicant';
import { CommonService } from 'app/module/shared/common.service';

@Component({
  selector: 'app-progress-bar',
  templateUrl: './progress-bar.component.html',
  styleUrls: ['./progress-bar.component.css']
})
export class ProgressBarComponent implements OnInit {

  constructor(private commanservice:CommonService,private routes:ActivatedRoute) { }
  appObj:Applicant
  length:number;
  status:string;
  ngOnInit(): void {
    this.getbar();
   
  }

  getbar()
  {
    this.routes.paramMap.subscribe(param1=>{
      this.commanservice.getApplicant((param1.get('applicantId'))).subscribe(data=>{
        this.appObj=data;

       // alert(this.appObj.status)
       if(this.appObj.status==="APPLICATION_GENERATED"){
        this.length=25;
        this.status="Application Generated"
      }
        if(this.appObj.status==="DOCUMENTS_VERIFIED"){
          this.length=50;
          this.status="Documents Verified"
        }
        if(this.appObj.status==="LOAN_SANCTIONED"){
          this.length=75;
          this.status="Loan sanctioned"
        }
        if(this.appObj.status==="LOAN_DISBURSED"){
          this.length=100;
          this.status="Loan Disbursed"
        }
  //  alert(this.length);
      })
    })

  }
  
}
