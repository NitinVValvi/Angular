import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Location } from '@angular/common';
import { CommonService } from 'app/module/shared/common.service';
@Component({
  selector: 'app-employee-update',
  templateUrl: './employee-update.component.html',
  styleUrls: ['./employee-update.component.css']
})
export class EmployeeUpdateComponent implements OnInit {

  constructor(private formbuilder:FormBuilder,private locations:Location,private commonservice:CommonService) { }
  updateForm:FormGroup;
  ngOnInit(): void {
    this.updateForm=this.formbuilder.group({
      employeeid:[],
      employeename:[''],
      employeeemail:[''],
      employeepassword:[''],
      employeemobile:[''],
      employeedesignation:[''],
      employeesalary:[''],
    })
    this.editData();
}
editData()
{
 let empObj:any=this.locations.getState();
 console.log("getState()" +empObj.employeeid);
 if(empObj.employeeid!=0)
 {
   this.updateForm.get('employeeid').setValue(empObj.employeeid);
   this.updateForm.get('employeename').setValue(empObj.employeename);
   this.updateForm.get('employeeemail').setValue(empObj.employeeemail);
   this.updateForm.get('employeepassword').setValue(empObj.employeepassword);
   this.updateForm.get('employeemobile').setValue(empObj.employeemobile);
   this.updateForm.get('employeedesignation').setValue(empObj.employeedesignation);
   this.updateForm.get('employeesalary').setValue(empObj.employeesalary);
 }
}
 goBack()
 {
   this.locations.back();
 }
 onSubmit()
 {
   this.commonservice.updateData(this.updateForm.value).subscribe();
   this.locations.back();
 }


}
