import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

  transform(value: any,filteredString:string) {
    // if(value.length===0){
    //   return value;
    // }
    const Applist=[];
    for(const app of value){
      if(app['applicantFname']===filteredString){
        Applist.push(app);
      }
    }
    return Applist;
  }

}
