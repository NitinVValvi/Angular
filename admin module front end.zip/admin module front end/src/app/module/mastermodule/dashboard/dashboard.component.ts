import { Component, OnInit } from '@angular/core';
import { CommonService } from 'app/module/shared/common.service';




@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private cs:CommonService) { }
empcount:any;
apcount:any;
appstatuscount:number;
apploancount:number;
verifiedcount:number;
disb1count:number;
appgenlist:any;
reccount:number;
today=Date.now();
aid:number;
areason:any;
//appsaclist:any;
  ngOnInit(): void {
    this.getcount();
    this.appcount();
    this.getcountapp();
    this.getcountloan();
    this.loanverifiedcount();
    this.disbcount();
    
  }

  getcount()
  {
    this.cs.getemployeecount().subscribe(data=>{
      this.empcount=data
     // alert(this.empcount)
    });
  }

  appcount(){
    this.cs.getAppliCount().subscribe(data=>{
      this.apcount=data;
    });
   // alert(this.apcount);
  }
   
  getcountapp()
  {
      this.cs.getbystatus("APPLICATION_GENERATED").subscribe(data=>{
    this.appstatuscount=data;
  });
   // alert(this.appstatuscount);
  }

  getcountloan()
  {
    this.cs.getbystatus("LOAN_SANCTIONED").subscribe(data=>{
      this.apploancount=data;
    });
  }
  loanverifiedcount()
  {
    this.cs.getbystatus("DOCUMENTS_VERIFIED").subscribe(data=>{
      this.verifiedcount=data;
    });
  }

  loanregcount()
  {
    this.cs.getbystatus("DOCUMENTS_REJECTED").subscribe(data=>{
      this.reccount=data;
    });
  }

  disbcount()
  {
    this.cs.getbystatus("LOAN_DISBURSED").subscribe(data=>{
      this.disb1count=data;
    });
  }

  getgen()
  {
    this.cs.getlistappgen("APPLICATION_GENERATED").subscribe(data=>{
      this.appgenlist=data;
    });
  }

  getsac()
  {
    this.cs.getlistappgen("LOAN_SANCTIONED").subscribe(data=>{
      this.appgenlist=data;
    });
    
  }
  getdocv()
  {
    this.cs.getlistappgen("DOCUMENTS_VERIFIED").subscribe(data=>{
      this.appgenlist=data;
    });
  }

  getdisb()
  {
    this.cs.getlistappgen("LOAN_DISBURSED").subscribe(data=>{
      this.appgenlist=data;
    });
  }

  getrec()
  {
    this.cs.getlistappgen("DOCUMENTS_REJECTED").subscribe(data=>{
      this.appgenlist=data;
    });
  }

  submit()
  {
    
    this.cs.getreason(this.aid).subscribe(data=>{
      this.areason=data;
    })
    
  }
}

