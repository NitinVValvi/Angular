import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applicant-byname',
  templateUrl: './applicant-byname.component.html',
  styleUrls: ['./applicant-byname.component.css']
})
export class ApplicantBynameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
