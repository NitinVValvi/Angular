import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { EmployeeUpdateComponent } from './employee-update/employee-update.component';
import { EmployeeregisterComponent } from './employeeregister/employeeregister.component';
import { ApplicantComponent } from './applicant/applicant.component';
import { ApplicantDetailsComponent } from './applicant-details/applicant-details.component';
import { ProgressBarComponent } from './progress-bar/progress-bar.component';
import { ApplicantBynameComponent } from './applicant-byname/applicant-byname.component';
import { SearchFilterPipe } from './search-filter.pipe';
import { BudgetComponent } from './budget/budget.component';
import { BudgetnewComponent } from './budgetnew/budgetnew.component';


const adminrouting: Routes = [
  {path: 'adminbash', component: DashboardComponent},
  {path:'employee',component:EmployeeComponent,
  children:[
  {path:'',component:EmployeeListComponent,
  children:[
  {path:'employee-update',component:EmployeeUpdateComponent},
  {path:'employee-details/:employeeid',component:EmployeeDetailsComponent},
  {path:'employee-register',component:EmployeeregisterComponent}
  ]}
  ]},
  { path:'applicant',component:ApplicantComponent,
children:[
  {path:'applicant-details/:applicantId',component:ApplicantDetailsComponent},
  {path:'progress-bar/:applicantId',component:ProgressBarComponent},
  {path:'applicantby-name' , component:ApplicantBynameComponent}
]},
{path:'budget',component:BudgetComponent,
children:[
  {path:'newbudget',component:BudgetnewComponent}
]}
];

@NgModule({
  declarations: [DashboardComponent, EmployeeComponent, EmployeeListComponent, EmployeeDetailsComponent, EmployeeUpdateComponent, EmployeeregisterComponent, ApplicantComponent, ApplicantDetailsComponent, ProgressBarComponent, ApplicantBynameComponent, SearchFilterPipe, BudgetComponent, BudgetnewComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(adminrouting)
  ]
})
export class MastermoduleModule { }
