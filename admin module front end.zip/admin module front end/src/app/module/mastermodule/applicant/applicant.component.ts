import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Applicant } from 'app/model/applicant';
import { CommonService } from 'app/module/shared/common.service';

@Component({
  selector: 'app-applicant',
  templateUrl: './applicant.component.html',
  styleUrls: ['./applicant.component.css']
})
export class ApplicantComponent implements OnInit {

  today=Date.now();
  constructor(private router:Router,private cs:CommonService) { }

  Applist:Applicant[];

  filteredString:string='';
  ngOnInit(): void {
    this.cs.getApplist().subscribe((data:Applicant[])=>{
      this.Applist=data;
    });

  }
  name:string;

  search(){
    alert(this.name)
  }
}
