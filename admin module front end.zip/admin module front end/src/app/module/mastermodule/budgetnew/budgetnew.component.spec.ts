import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BudgetnewComponent } from './budgetnew.component';

describe('BudgetnewComponent', () => {
  let component: BudgetnewComponent;
  let fixture: ComponentFixture<BudgetnewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BudgetnewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BudgetnewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
