import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from 'app/module/shared/common.service';

@Component({
  selector: 'app-budgetnew',
  templateUrl: './budgetnew.component.html',
  styleUrls: ['./budgetnew.component.css']
})
export class BudgetnewComponent implements OnInit {

  constructor(private cs: CommonService,private fb:FormBuilder) { }
  
  
  
  budgetForm:FormGroup;
  ngOnInit(): void {
    this.budgetForm=this.fb.group({
      budgetId:[],
      duration:[''],
      budgetAmount:[],
      currentAmount:[]
    });
  }

  onSubmit()
  {
  //  alert("In budget new")
    alert(this.budgetForm.value.budgetId);
    this.cs.postbudget(this.budgetForm.value).subscribe();
  }
}
