import { Component, OnInit } from '@angular/core';
import { Employee } from 'app/model/employee';
import { CommonService } from 'app/module/shared/common.service';
//import jsPDF from 'jspdf';
//import html2canvas from 'html2canvas';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(public commonservice:CommonService) { }
  
  empList:Employee[];
  ngOnInit(): void {
    this.commonservice.getData().subscribe((data:Employee[])=>{
      this.empList=data;
    })
  }
  deleteData(employeeid:number)
  {
    this.commonservice.deleteData(employeeid).subscribe();
    window.location.reload();
  }

  d:any;

  //openPDF()
  //{
    //this.d=document.getElementById('htmlData');
   // html2canvas(this.d).then(canvas=>{
    //  let fileWidth=290;
      //let fileHeight=200;
      //const FileURI=canvas.toDataURL('image/png');
      //let PDF=new jsPDF('p','mm','a3');
      //PDF.addImage(FileURI,0,0,fileWidth,fileHeight);
      //PDF.save('employee-crud.pdf');
        //});
  //}
//}


}
