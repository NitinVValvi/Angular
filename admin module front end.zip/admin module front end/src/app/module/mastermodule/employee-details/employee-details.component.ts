import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Employee } from 'app/model/employee';
import { CommonService } from 'app/module/shared/common.service';
import {Location } from '@angular/common'
@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

 
  constructor(private routes:ActivatedRoute,private commonservice:CommonService,private locations:Location) { }
  empObj:Employee;
  ngOnInit(): void {

   this.routes.paramMap.subscribe(param1=>{
    this.commonservice.getEmployee(parseInt(param1.get('employeeid'))).subscribe(data=>{
      this.empObj=data;
    })
  })
 }
 getBack()
 {
   this.locations.back();
 }
  
}
