import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from 'app/module/shared/common.service';

@Component({
  selector: 'app-employeeregister',
  templateUrl: './employeeregister.component.html',
  styleUrls: ['./employeeregister.component.css']
})
export class EmployeeregisterComponent implements OnInit {

  constructor(public commonservice:CommonService,private formbuider:FormBuilder,private loc:Location) { }
  registerForm:FormGroup;
  email:any={
    toEmail:'',
    subject:'',
    textMsg:''
  }
  ngOnInit(): void {
    this.registerForm=this.formbuider.group({
      employeeid:[0],
      employeename: [''],
      employeeemail:[''],
      employeepassword:[''],
      employeemobile:[''],
      employeedesignation:[''],
      employeesalary:['']
    })
  }
  onSubmit()
  {
    if(this.registerForm.valid)
    {
     
    this.commonservice.postData(this.registerForm.value).subscribe();
    window.location.reload();
    alert("Registered Successfully...!!!")
      this.email={
        toEmail: this.registerForm.value.employeeemail,
       subject:"Wellcome To furniture Finace",
       textMsg:"Your Mail Id is your username and password is "+this.registerForm.value.employeepassword,
      }
      alert(this.email.toEmail)
      this.commonservice.sendEmail(this.email).subscribe();
    }
  }
  goBack(){
    this.loc.back();
  }
}
