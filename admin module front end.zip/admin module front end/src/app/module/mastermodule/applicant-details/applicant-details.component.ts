import { Component, OnInit } from '@angular/core';
import { Applicant } from 'app/model/applicant';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'app/module/shared/common.service';
@Component({
  selector: 'app-applicant-details',
  templateUrl: './applicant-details.component.html',
  styleUrls: ['./applicant-details.component.css']
})
export class ApplicantDetailsComponent implements OnInit {

  constructor(private location:Location,private routes:ActivatedRoute,private commonservice:CommonService) { }
  appObj:Applicant;
  ngOnInit(): void {
    this.routes.paramMap.subscribe(param1=>{
      this.commonservice.getApplicant((param1.get('applicantId'))).subscribe(data=>{
        this.appObj=data;
    
      })
    })
  }

  getBack(){
    this.location.back();
  }
}
