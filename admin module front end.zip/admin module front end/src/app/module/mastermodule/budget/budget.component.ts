import { Component, OnInit } from '@angular/core';
import { Budget } from 'app/model/budget';
import { CommonService } from 'app/module/shared/common.service';

@Component({
  selector: 'app-budget',
  templateUrl: './budget.component.html',
  styleUrls: ['./budget.component.css']
})
export class BudgetComponent implements OnInit {

  constructor(private cs:CommonService) { }
  bugList:Budget[];
  today=Date.now();
  ngOnInit(): void {
    this.cs.getAllBudget().subscribe(data=>{
      this.bugList=data;
   //   alert("hi");
    });
  }

}
