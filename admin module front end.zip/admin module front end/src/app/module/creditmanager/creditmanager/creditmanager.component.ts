import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creditmanager',
  templateUrl: './creditmanager.component.html',
  styleUrls: ['./creditmanager.component.css']
})
export class CreditmanagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
