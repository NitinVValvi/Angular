import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doccomp',
  templateUrl: './doccomp.component.html',
  styleUrls: ['./doccomp.component.css']
})
export class DoccompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
