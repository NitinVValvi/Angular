import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DoccompComponent } from './doccomp/doccomp.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

const docrouting: Routes = [
  {path: 'docgen1', component: DoccompComponent}
]
//alert("IN DOC MODULE");
@NgModule({
  declarations: [DoccompComponent],
  imports: [
    CommonModule,RouterModule.forChild(docrouting),FormsModule
  ]
})
export class DocVerificationModule { }
