import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Employee } from 'app/model/employee';
import { environment } from 'environments/environment';
import { Applicant } from 'app/model/applicant';
import { Budget } from 'app/model/budget';
@Injectable({
  providedIn: 'root'
})
export class CommonService {


  constructor(private httpclient:HttpClient) { }
  e:Employee={
    employeeid: 0,
    employeename: '',
    employeeemail:'',
    employeepassword:'',
    employeemobile:'',
    employeedesignation:'',
    employeesalary:''
  }
 private serverurl=environment.url;
  checklogin(u:string,p:string):Observable<Employee>
  {
    return this.httpclient.get<Employee>(this.serverurl+"/getsinglebyuser/"+u+"/"+p);
  }

  getData():Observable<Employee[]>
  {
    return this.httpclient.get<Employee[]>(this.serverurl+"/getlist");
  }
  deleteData(employeeid:number):Observable<Employee>
  {
    return this.httpclient.delete<Employee>(this.serverurl+"/delete/"+employeeid);
  }
  postData(emp:Employee):Observable<Employee>
  {
    return this.httpclient.post<Employee>(this.serverurl+"/insert/",emp)
  }
  updateData(emp:Employee):Observable<Employee>
  {
    return this.httpclient.put<Employee>(this.serverurl+"/update/",emp)
  }
  getEmployee(employeeid:number):Observable<Employee>
  {
    return this.httpclient.get<Employee>(this.serverurl+"/getsingle/"+employeeid);
  }
  sendEmail(email:any):Observable<any>{
    return this.httpclient.post<any>(this.serverurl+"/send",email);
  }

  //applicatant opps
  getApplist():Observable<Applicant[]>{
    return this.httpclient.get<Applicant[]>(this.serverurl+"/getAll");
  }
  getApplicant(applicantId:any):Observable<Applicant>
  {
    return this.httpclient.get<Applicant>(this.serverurl+"/getappl/"+applicantId);
  }
  empcount:any;
  getemployeecount():Observable<any>
  {
    
    return this.httpclient.get<any>(this.serverurl+"/getemployeecount");
  }
  getAppliCount():Observable<any>{
    return this.httpclient.get<any>(this.serverurl+"/getapplicantcount")
  }

  getbystatus(status:string):Observable<number>
  {
    
    return this.httpclient.get<number>(this.serverurl+"/getbystatus/"+status);
    
  }

  getlistappgen(status:string)
  {
    return this.httpclient.get<any>(this.serverurl+"/getlistbystatus/"+status)
  }

  getAllBudget():Observable<Budget[]>
  {
    return this.httpclient.get<Budget[]>(this.serverurl+"/AllBudget");
  }

  postbudget(b:Budget):Observable<Budget>
  {
    alert("In Budget");
    alert(b.budgetId);
    return this.httpclient.post<Budget>(this.serverurl+"/budget",b);
  }

  getreason(id:number):Observable<any>
  {
    alert(id);
    return this.httpclient.get<any>(this.serverurl+"/getreason/"+id);
  }
}
