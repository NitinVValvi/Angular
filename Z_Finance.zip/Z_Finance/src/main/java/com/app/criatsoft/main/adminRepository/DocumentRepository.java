package com.app.criatsoft.main.adminRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.criatsoft.main.adminModel.Document;

public interface DocumentRepository extends JpaRepository<Document, Integer>{

	String getByReason(int id);

}
