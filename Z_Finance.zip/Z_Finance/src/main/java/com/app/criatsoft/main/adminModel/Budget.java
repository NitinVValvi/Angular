package com.app.criatsoft.main.adminModel;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Budget {
	@Id
	private int budgetId;
	private String duration;
	private long budgetAmount;
	public int getBudgetId() {
		return budgetId;
	}
	public void setBudgetId(int budgetId) {
		this.budgetId = budgetId;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public long getBudgetAmount() {
		return budgetAmount;
	}
	public void setBudgetAmount(long budgetAmount) {
		this.budgetAmount = budgetAmount;
	}
	public long getCurrentAmount() {
		return currentAmount;
	}
	public void setCurrentAmount(long currentAmount) {
		this.currentAmount = currentAmount;
	}
	private long currentAmount;
}
