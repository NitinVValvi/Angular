package com.app.criatsoft.main.adminRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.criatsoft.main.adminModel.Budget;

public interface BudgetRepository extends JpaRepository<Budget, Integer>{

}
