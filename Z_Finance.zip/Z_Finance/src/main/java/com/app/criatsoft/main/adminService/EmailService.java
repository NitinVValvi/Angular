package com.app.criatsoft.main.adminService;

import com.app.criatsoft.main.adminModel.EmailSender;

public interface EmailService {

	void sendEmail(EmailSender eml);

}
