export class Menu {
  public static menu: Array<any> = [
    {
      admin: [
        { path: 'adminbash', title: 'Dashboard', icon: 'pe-7s-graph', class: '' },
        { path: 'addenq', title: 'Add Enquiry', icon: 'pe-7s-graph', class: '' },

        { path: 'city', title: 'Create Student', icon: 'pe-7s-graph', class: '' },
        { path: 'addbatch', title: 'Add Batch', icon: 'pe-7s-graph', class: '' },
        { path: 'viewbatch', title: 'View BAtch', icon: 'pe-7s-graph', class: '' }


      ],
      emp: [
        { path: 'empdash', title: 'dashbord', icon: 'pe-7s-graph', class: '' },
        { path: 'demo', title: 'Demmmo', icon: 'pe-7s-graph', class: '' }
      ],
      operation: [
        { path: 'oedash', title: 'DASHBORD', icon: 'pe-7s-graph', class: '' },
        { path: 'oeenq', title: 'VIEW ENQUIERY', icon: 'pe-7s-graph', class: '' },
        { path: 'oecustomer', title: 'VIEW CUSTOMER', icon: 'pe-7s-graph', class: '' },
        { path: 'cibil', title: 'CIBILSCORE', icon: 'pe-7s-graph', class: '' }
      ],
      relation: [
        { path: 'oeenquiry', title: 'ENQUERY', icon: 'pe-7s-graph', class: '' },
        { path: 'oecustomer', title: 'REGISTER CUSTOMER', icon: 'pe-7s-graph', class: '' },
        { path: 'oedocument', title: 'UPLOAD DOCUMENT', icon: 'pe-7s-graph', class: '' }

      ],
      cr: [{ path: 'credit', title: 'ENQUERY', icon: 'pe-7s-graph', class: '' },

      ],
      ab: [{ path: 'abcdash', title: 'DASHBOARD', icon: 'pe-7s-graph', class: '' }],
      b134: [{ path: 'b134dash', title: '134DASHBOARD', icon: 'pe-7s-graph', class: '' }],


      b135: [{ path: 'adminbash', title: 'Dashboard222', icon: 'pe-7s-graph', class: '' }],
      b136: [{ path: 'b136dash', title: 'B136', icon: 'pe-7s-graph', class: '' }],
      b137: [{ path: 'adminbash', title: 'BATCH1377777', icon: 'pe-7s-graph', class: '' },
      { path: 'aa', title: 'BATCH', icon: 'pe-7s-graph', class: '' }]


    }
  ];
}
