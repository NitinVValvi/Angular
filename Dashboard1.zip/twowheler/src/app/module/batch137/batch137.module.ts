import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B137dashboardComponent } from './b137dashboard/b137dashboard.component';
import { RouterModule, Routes } from '@angular/router';

const adminrouting: Routes = [
  { path: 'adminbash', component: B137dashboardComponent }


];


@NgModule({
  declarations: [B137dashboardComponent],
  imports: [
    CommonModule, RouterModule.forChild(adminrouting)
  ]
})
export class Batch137Module { }
