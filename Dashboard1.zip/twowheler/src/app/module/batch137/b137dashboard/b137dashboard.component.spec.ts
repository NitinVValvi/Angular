import { ComponentFixture, TestBed } from '@angular/core/testing';

import { B137dashboardComponent } from './b137dashboard.component';

describe('B137dashboardComponent', () => {
  let component: B137dashboardComponent;
  let fixture: ComponentFixture<B137dashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ B137dashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(B137dashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
