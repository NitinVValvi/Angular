import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b137dashboard',
  templateUrl: './b137dashboard.component.html',
  styleUrls: ['./b137dashboard.component.css']
})
export class B137dashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
