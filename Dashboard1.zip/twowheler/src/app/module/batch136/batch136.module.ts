import { Component, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B136componentComponent } from './b136component/b136component.component';
import { RouterModule, Routes } from '@angular/router';

const b13routes: Routes = [
  {
    path: 'b136dash' , component: B136componentComponent
  }
]


@NgModule({
  declarations: [B136componentComponent],
  imports: [
    CommonModule, RouterModule.forChild(b13routes)
  ]
})
export class Batch136Module { }
