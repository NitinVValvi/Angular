import { ComponentFixture, TestBed } from '@angular/core/testing';

import { B136componentComponent } from './b136component.component';

describe('B136componentComponent', () => {
  let component: B136componentComponent;
  let fixture: ComponentFixture<B136componentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ B136componentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(B136componentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
