import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b136component',
  templateUrl: './b136component.component.html',
  styleUrls: ['./b136component.component.css']
})
export class B136componentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
