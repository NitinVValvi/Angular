import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Batch134dashComponent } from './batch134dash.component';

describe('Batch134dashComponent', () => {
  let component: Batch134dashComponent;
  let fixture: ComponentFixture<Batch134dashComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Batch134dashComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Batch134dashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
