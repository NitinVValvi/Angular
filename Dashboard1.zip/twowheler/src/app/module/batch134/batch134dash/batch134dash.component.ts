import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batch134dash',
  templateUrl: './batch134dash.component.html',
  styleUrls: ['./batch134dash.component.css']
})
export class Batch134dashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
