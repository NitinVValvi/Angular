import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Batch134dashComponent } from './batch134dash/batch134dash.component';
import { RouterModule, Routes,  } from '@angular/router';

const b134routing: Routes = [
{path: 'b134dash', component: Batch134dashComponent
}
]

@NgModule({
  declarations: [Batch134dashComponent],
  imports: [
    CommonModule , RouterModule.forChild(b134routing)
  ]
})
export class Batch134Module { }
