import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddStudentComponent } from './add-student/add-student.component';
import { FormsModule } from '@angular/forms';
import { AddbatchComponent } from './addbatch/addbatch.component';
import { ViewbatchComponent } from './viewbatch/viewbatch.component';
import { AddenquiryComponent } from './addenquiry/addenquiry.component';

const adminrouting: Routes = [
  { path: 'adminbash', component: DashboardComponent },
  { path: 'city', component: AddStudentComponent },
  { path: 'addbatch', component: AddbatchComponent },
  { path: 'viewbatch', component: ViewbatchComponent },
  { path: 'addenq', component: AddenquiryComponent }



];

@NgModule({
  declarations: [DashboardComponent, AddStudentComponent, AddbatchComponent, ViewbatchComponent, AddenquiryComponent],
  imports: [
    CommonModule, RouterModule.forChild(adminrouting), FormsModule
  ]
})
export class MastermoduleModule { }
