import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addbatch',
  templateUrl: './addbatch.component.html',
  styleUrls: ['./addbatch.component.css']
})
export class AddbatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
