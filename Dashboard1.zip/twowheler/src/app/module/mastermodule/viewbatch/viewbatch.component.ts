import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewbatch',
  templateUrl: './viewbatch.component.html',
  styleUrls: ['./viewbatch.component.css']
})
export class ViewbatchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
