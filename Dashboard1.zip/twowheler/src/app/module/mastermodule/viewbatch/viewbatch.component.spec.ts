import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewbatchComponent } from './viewbatch.component';

describe('ViewbatchComponent', () => {
  let component: ViewbatchComponent;
  let fixture: ComponentFixture<ViewbatchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewbatchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewbatchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
