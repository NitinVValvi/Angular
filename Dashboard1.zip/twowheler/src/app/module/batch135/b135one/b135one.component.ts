import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-b135one',
  templateUrl: './b135one.component.html',
  styleUrls: ['./b135one.component.css']
})
export class B135oneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
