import { ComponentFixture, TestBed } from '@angular/core/testing';

import { B135oneComponent } from './b135one.component';

describe('B135oneComponent', () => {
  let component: B135oneComponent;
  let fixture: ComponentFixture<B135oneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ B135oneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(B135oneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
