import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { B135oneComponent } from './b135one/b135one.component';
import { RouterModule, Routes } from '@angular/router';

const b135routing: Routes =  [
  { path: 'adminbash', component: B135oneComponent },


];


@NgModule({
  declarations: [B135oneComponent],
  imports: [
    CommonModule, RouterModule.forChild(b135routing)
  ]
})
export class Batch135Module { }
