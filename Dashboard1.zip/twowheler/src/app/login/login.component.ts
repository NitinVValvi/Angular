import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// tslint:disable-next-line:class-name
export interface user {
  username: string;
  password: string;
  repassword: string;
  email: string;
}
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  u: user = {
    username: '',
    password: '',
    repassword: '',
    email: ''
  };
  // tslint:disable-next-line:member-ordering
  username: String = '';
  password: String = '';
  constructor(private router: Router) {}
  ngOnInit() {}
  login(u) {
    console.log('login called');
    console.log(u.username, u.password);

    if (u.username === 'cjc' && u.password === 'cjc') {
      console.log('in admin');
      sessionStorage.setItem('role', 'admin');
      this.router.navigateByUrl('role/admin/adminbash');
    }
    if (u.username === 'b137' && u.password === 'b137') {
      console.log('in b137');
      sessionStorage.setItem('role', 'b137');
      this.router.navigateByUrl('role/b137/adminbash');
    }
    if (u.username === 'emp' && u.password === 'emp') {
      console.log('in emp');
      sessionStorage.setItem('role', 'emp');
      this.router.navigateByUrl('role/emp/empdash');
    }
    if (u.username === 'oe' && u.password === 'oe') {
      sessionStorage.setItem('role', 'operation');
      this.router.navigateByUrl('role/operation/oedash');
    }
    if (u.username === 'cm' && u.password === 'cm') {
      console.log(u.username, u.password);
      sessionStorage.setItem('role', 'cr');
      this.router.navigateByUrl('role/cr/credit');
    }
    if (u.username === 're' && u.password === 're') {
      console.log(u.username, u.password);
      sessionStorage.setItem('role', 'relation');
      this.router.navigateByUrl('role/relation/oecustomer');
    }
    if (u.username === 'abc' && u.password === 'abc') {
      console.log(u.username, u.password);
      sessionStorage.setItem('role', 'ab');
      this.router.navigateByUrl('role/ab/abcdash');
    }
    if (u.username === '1' && u.password === '1') {
      console.log(u.username, u.password);
      sessionStorage.setItem('role', 'b134');
      this.router.navigateByUrl('role/b134/b134dash');
    }
    if (u.username === '2' && u.password === '2') {
      console.log(u.username, u.password);
      sessionStorage.setItem('role', 'b135');
      this.router.navigateByUrl('role/b135/adminbash');
    }
    if (u.username === '136' && u.password === '136') {
      console.log(u.username, u.password);
      sessionStorage.setItem('role', 'b136');
      this.router.navigateByUrl('role/b136/b136dash');
    }

  }
  signup(u) {
    console.log('signup');
  }
  register() {
  this.router.navigate(['/reg'])
  }
}
