import { MastermoduleModule } from './module/mastermodule/mastermodule.module';
import { Routes } from '@angular/router';

import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { LoginComponent } from './login/login.component';
import { EmployeeModule } from './module/employee/employee.module';
import { HomeComponent } from './home/home.component';
import { OperationexecutiveModule } from './module/operationexecutive/operationexecutive.module';
import { CreditmanagerModule } from './module/creditmanager/creditmanager.module';
import { RelationexecutiveModule } from './module/relationexecutive/relationexecutive.module';
import { AbcModule } from './module/abc/abc.module';
import { RegisterComponent } from './register/register.component';
import { Batch134Module } from './module/batch134/batch134.module';
import { Batch135Module } from './module/batch135/batch135.module';
import { Batch136Module } from './module/batch136/batch136.module';
import { Batch137Module } from './module/batch137/batch137.module';



export const AppRoutes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'reg',
    component: RegisterComponent
  },
  {
    path: 'log', component: LoginComponent
  }
,
  {
    path: 'role',
    component: AdminLayoutComponent,
    children: [

      {path: 'admin', loadChildren: () => MastermoduleModule},
      {path: 'emp', loadChildren: () => EmployeeModule},
      {path:'operation',loadChildren:()=>OperationexecutiveModule},
      {path:'cr',loadChildren:()=>CreditmanagerModule},
      {path: 'relation', loadChildren:()=>RelationexecutiveModule},
      {path: 'ab', loadChildren:()=>AbcModule},
      {path: 'b134', loadChildren: () => Batch134Module},
      {path: 'b135', loadChildren: () => Batch135Module},
      {path: 'b136', loadChildren: () => Batch136Module},
      {path: 'b137', loadChildren: () => Batch137Module}


    ]
  },
  {
    path: '**',
    redirectTo: 'dashboard'
  }
];



