import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplistComponent } from './applist/applist.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

const loanrouting: Routes = [
  {path: 'loang1', component: ApplistComponent}
]

@NgModule({
  declarations: [ApplistComponent],
  imports: [
    CommonModule,RouterModule.forChild(loanrouting),FormsModule
  ]
})
export class LoanSanctionModule { }
