import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DoccompComponent } from './doccomp.component';

describe('DoccompComponent', () => {
  let component: DoccompComponent;
  let fixture: ComponentFixture<DoccompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DoccompComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DoccompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
