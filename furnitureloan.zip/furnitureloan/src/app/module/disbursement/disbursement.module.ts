import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DisburcelistComponent } from './disburcelist/disburcelist.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

const discrouting: Routes = [
  {path: 'disg1', component: DisburcelistComponent}
]

alert("IN DIS MODULE");
@NgModule({
  declarations: [DisburcelistComponent],
  imports: [
    CommonModule,RouterModule.forChild(discrouting),FormsModule
  ]
})
export class DisbursementModule { }
