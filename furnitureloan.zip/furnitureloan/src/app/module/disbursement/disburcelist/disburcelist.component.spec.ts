import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisburcelistComponent } from './disburcelist.component';

describe('DisburcelistComponent', () => {
  let component: DisburcelistComponent;
  let fixture: ComponentFixture<DisburcelistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisburcelistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisburcelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
